@echo off

REM Set the variables
SET PI_USER=ravidayani
SET PI_IP=raspberrypi.local
SET PI_PASSWORD=R@vi442Dayani
SET LOCAL_PATH=C:\Users\det010\Desktop\version2

REM SSH into the Raspberry Pi and execute commands
echo Running SSH command on Raspberry Pi...
plink.exe -ssh %PI_USER%@%PI_IP% -pw %PI_PASSWORD% -batch "cd Desktop && source myenv/bin/activate && cd raspberrypi/version_2 && python version2.py"

REM Copy files from Raspberry Pi to local machine
echo Copying files from Raspberry Pi to local machine...
pscp.exe -pw %PI_PASSWORD% -r %PI_USER%@%PI_IP%:/home/ravidayani/Desktop/raspberrypi/version_2 %LOCAL_PATH%

echo Script execution completed.
