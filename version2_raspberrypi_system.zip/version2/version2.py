#!/usr/bin/env python

import cv2
import time
import board
import busio
import numpy as np
import adafruit_mlx90640
import matplotlib.pyplot as plt
import pandas as pd 

# Open a connection to the camera
camera = cv2.VideoCapture(0)

# Setup I2C and initialize MLX90640
i2c = busio.I2C(board.SCL, board.SDA, frequency=400000)
mlx = adafruit_mlx90640.MLX90640(i2c)
mlx.refresh_rate = adafruit_mlx90640.RefreshRate.REFRESH_2_HZ

# Prepare an Excel writer to save data
excel_file = "thermal_data.xlsx"
excel_writer = pd.ExcelWriter(excel_file, engine='openpyxl')

# Check if the camera opened successfully
if not camera.isOpened():
    print("Error: Could not open camera.")
    exit()

# List to store average temperatures for each frame
avg_temperatures = []

# Capture 20 frames
for i in range(20):
    # Setup array for storing temperatures (24x32 grid)
    fram = np.zeros((24*32,))

    # Read the frame from the MLX90640 sensor
    while True:
        try:
            mlx.getFrame(fram)
            break
        except ValueError:
            continue  # retry reading if there's an error

    # Convert 1D array to a 2D array (24x32) for visualization
    thermal_data = np.reshape(fram, (24, 32))

    # Calculate the average temperature
    avg_temp = np.mean(fram)
    avg_temperatures.append(avg_temp)  # Append average temperature to the list

    # Print out the average temperature (optional)
    print('Average MLX90640 Temperature: {0:2.1f}C ({1:2.1f}F)'.\
          format(avg_temp, (((9.0/5.0)*avg_temp)+32.0)))

    # Capture a single frame (image) from the camera
    ret, frame = camera.read()

    # Check if the frame was captured successfully
    if ret:
        # Save the captured image to a file
        filename = f"captured_image_{i+1}.bmp"
        cv2.imwrite(filename, frame)
        print(f"Image {i+1} captured and saved successfully.")
    else:
        print(f"Error: Could not capture image {i+1}.")

# Release the camera
camera.release()

# Close any OpenCV windows
cv2.destroyAllWindows()

# Convert the list of average temperatures into a DataFrame (one column)
df = pd.DataFrame(avg_temperatures, columns=['Average Temperature (C)'])

# Save the DataFrame to Excel (all 20 temperatures in a single sheet)
df.to_excel(excel_writer, index=False)

# Close the Excel writer
excel_writer.close()

print(f"Thermal data saved to {excel_file}")
